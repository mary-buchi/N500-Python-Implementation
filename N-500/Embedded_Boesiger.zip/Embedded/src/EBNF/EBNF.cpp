// TestCE.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "EBNF.h"
#include "EBNFmain.h"

#include "EBSYmain.h"

#include "EBPImain.h"
#include "EBPIenum.h"
#include "EBPIfact.h"
#include "EBPIintf.h"
#include "EBCOsync.h"
#include "EBCOexcp.h"

#include "EBHIintf.h"
#include "EBHIthrd.h"
#include "EBHITtype.h"


static void InitSocket()
{
    WORD wVersionRequested;
    WSADATA wsaData;
    int err;
 
    wVersionRequested = MAKEWORD( 2, 2 );
 
    err = WSAStartup( wVersionRequested, &wsaData );
    ASSERT(err == 0);
}


/////////////////////////////////////////////////////////////////////////////
// CTestCEApp

BEGIN_MESSAGE_MAP(CTestCEApp, CWinApp)
	//{{AFX_MSG_MAP(CTestCEApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard file based document commands
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestCEApp construction

CTestCEApp::CTestCEApp()
	: CWinApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

CTestCEApp::~CTestCEApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CTestCEApp object

CTestCEApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CTestCEApp initialization

BOOL CTestCEApp::InitInstance()
{
  try
  {
    // Standard initialization
	  // If you are not using these features and wish to reduce the size
	  //  of your final executable, you should remove from the following
	  //  the specific initialization routines you do not need.

	  // Change the registry key under which our settings are stored.
	  // You should modify this string to be something appropriate
	  // such as the name of your company or organization.
	  SetRegistryKey(_T("Local AppWizard-Generated Applications"));


	  // Create System itself
      if (!CSYSystem::Create())
		  return FALSE;

	  // To create the main window, this code creates a new frame window
	  // object and then sets it as the application's main window object.

	  CMainFrame* pFrame = new CMainFrame;
	  m_pMainWnd = pFrame;

	  // create and load the frame with its resources

	  pFrame->LoadFrame(IDR_MAINFRAME,
		  WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE, NULL,
		  NULL);


	  // The one and only window has been initialized, so show and update it.
	  pFrame->ShowWindow(m_nCmdShow);
	  pFrame->UpdateWindow();

	  return TRUE;
  }
  catch(...)
  {
    AfxMessageBox(_T("Exception during startup!"));
    return FALSE;
  }
}

/////////////////////////////////////////////////////////////////////////////
// CTestCEApp message handlers





/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();		// Added for WCE apps
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CTestCEApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CTestCEApp commands
// Added for WCE apps

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CenterWindow();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
